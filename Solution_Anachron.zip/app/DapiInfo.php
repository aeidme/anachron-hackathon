<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DapiInfo extends Model
{
    protected $table= 'dapi_infos';
    public $primaryKey='id';
}
