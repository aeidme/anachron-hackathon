<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GoalAccountsModel extends Model
{
    protected $table= 'goalaccounts';
    public $primaryKey='goal_acc_id';
}
